import { FiltertypePipe } from './filtertype.pipe';

describe('FiltertypePipe', () => {
  it('create an instance', () => {
    const pipe = new FiltertypePipe();
    expect(pipe).toBeTruthy();
  });
});
