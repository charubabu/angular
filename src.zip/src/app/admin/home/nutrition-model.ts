export class nutrition{
    id : any
    Food: String;
    Measure: String;
    Grams: Number;
    Calories: Number;
    Protein: Number;
    Fat: Number;
    Sat_Fat: Number;
    Fiber: Number;
    Carbs: Number;
    Category: String
  }